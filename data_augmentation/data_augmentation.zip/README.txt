Reference github repo:

https://github.com/woshiwwwppp/ryolov3research-pytorch-master/tree/ebec0b567cfe31fb81cc43c1811987409a99127e/data_aug